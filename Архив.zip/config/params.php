<?php return array (
  'adminEmail' => 'admin@example.com',
  'senderEmail' => 'noreply@example.com',
  'senderName' => 'Example.com mailer',
  'bsVersion' => '4.x',
  'user_online_min' => '100',
  'user_online_max' => '120',
  'guest_online_min' => '20',
  'guest_online_max' => '30',
);